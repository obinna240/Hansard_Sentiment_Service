package gate.merger;

/*
 * Enum the methods for annotation merging.
 */
public enum MergingMethodsEnum {
  MajorityVoting, MergingByAnnotatorNum
}
